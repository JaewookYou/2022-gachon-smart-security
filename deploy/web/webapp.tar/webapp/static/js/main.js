(function($) {

	"use strict";


})(jQuery);