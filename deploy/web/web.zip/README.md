## web chall ##

how to run?
 1. install `docker` & `docker-compose`
 2. `$ sudo docker-compose build`
 3. `$ sudo docker-compose up`
 4. access to `[server's ip]:9090`
