#!/bin/bash
python3 /app/webapp/app.py&